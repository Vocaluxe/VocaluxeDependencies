DISCLAIMER: THIS LICENSING INFORMATION IS PROVIDED ON A BEST-EFFORT BASIS
AND IS NOT MEANT TO BE LEGAL ADVICE. PLEASE TALK TO A LAWYER FOR ADVICE ON
SOFTWARE LICENSE COMPLIANCE.

The libraries and binaries in this package may be used under the terms of license file(s):

LGPL-2.0-or-later.txt (AND) subprojects_gst-plugins-bad_ext_sctp_usrsctp_LICENSE.md